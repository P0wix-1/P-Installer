import subprocess, winreg, os

while True:
    print("1 - Запретить автообновление Windows 11\n2 - Запретить установку драйвера видеокарты\n3 - Исправить OpenGLDriver\n0 - Выход")
    choice = input("Выбор: ")

    match choice:
        case '1':
            subprocess.run(["disableUpdates.bat"], shell=True)

        case '2':
            command = "Get-WmiObject Win32_VideoController | Format-List PNPDeviceID"
            res = subprocess.run(["powershell", "-Command", command], capture_output=True, text=True)
            video_id = res.stdout
            vid=video_id.split()
            for i in vid:
                if "REV_A1" in i:
                    video_id = i.split("\\")
            vid=f"{video_id[0]}\\{video_id[1]}"
            device_ids = [
                vid,
                vid[:-7],
                vid[:-22]+"CC_030200",
                vid[:-22]+"CC_0302"
            ]
            BASE = r"SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Restrictions"
            LIST_SUBKEY = BASE + r"\DenyDeviceIDs"
            try:
                BASE = r"SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Restrictions"
                LIST_SUBKEY = BASE + r"\DenyDeviceIDs"

                with winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, BASE, 0, winreg.KEY_SET_VALUE) as k:
                    winreg.SetValueEx(k, "DenyDeviceIDs", 0, winreg.REG_DWORD, 1)  # включено[page:0]

                with winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, LIST_SUBKEY, 0, winreg.KEY_SET_VALUE) as lk:
                    i = 0
                    while True:
                        try:
                            name, _, _ = winreg.EnumValue(lk, 0)
                            winreg.DeleteValue(lk, name)
                            i += 1
                        except OSError:
                            break

                    for idx, hwid in enumerate(device_ids, start=1):
                        winreg.SetValueEx(lk, str(idx), 0, winreg.REG_SZ, hwid)

            except PermissionError:
                print("Ошибка: Запустите скрипт от имени Администратора!")

        case '3':
            folder = subprocess.run(["powershell", "-Command",
                                  r"Get-ChildItem 'HKLM:\SYSTEM\ControlSet001\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}' | Select-Object -ExpandProperty PSChildName"],
                                    capture_output=True, text=True).stdout
            folder = folder.split()
            folder = [s for s in folder if s.startswith("0")]

            driver_path=None
            directory=[]

            for i in folder:
                directory.append("Get-ItemProperty 'HKLM:\\SYSTEM\\ControlSet001\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\" + i + "' -Name 'OpenGLDriverName' | Format-List OpenGLDriverName")

            for i in range(len(directory)):
                driver_path = subprocess.run(["powershell", "-Command", directory[i]], capture_output=True, text=True).stdout
                driver_path = driver_path.split()
                driver_path = driver_path[2][1:-1]
                if driver_path[0] == "C":
                    os.system('reg add "HKLM\\SYSTEM\\ControlSet001\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\' + next(x for x in folder if x != folder[i]) + '" /v "OpenGLDriverName" /t REG_MULTI_SZ /d ' + '"' + driver_path + '"' + " /f")
                    print(True)

            driver_path = None
            directory = []

            for i in folder:
                directory.append("Get-ItemProperty 'HKLM:\\SYSTEM\\ControlSet001\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\" + i + "' -Name 'OpenGLDriverNameWoW' | Format-List OpenGLDriverNameWoW")

            for i in range(len(directory)):
                driver_path = subprocess.run(["powershell", "-Command", directory[i]], capture_output=True, text=True).stdout
                driver_path = driver_path.split()
                driver_path = driver_path[2][1:-1]
                if driver_path[0] == "C":
                    os.system('reg add "HKLM\\SYSTEM\\ControlSet001\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\' + next(x for x in folder if x != folder[i]) + '" /v "OpenGLDriverNameWoW" /t REG_MULTI_SZ /d ' + '"' + driver_path + '"' + " /f")
                    print(True)

            """base_key = r"HKLM:\SYSTEM\ControlSet001\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}"
            cmd = [
                "powershell",
                "-Command",
                rf"(Get-ChildItem '{base_key}' | Select-Object -ExpandProperty PSChildName) -join '\n'"
            ]
            out = subprocess.run(cmd, capture_output=True, text=True)
            out.check_returncode()
            folder = [s for s in out.stdout.splitlines() if s.startswith("0")]
            def get_prop(subkey, name):
                cmd = [
                    "powershell",
                    "-Command",
                    rf"(Get-ItemProperty '{base_key}\{subkey}').{name}"
                ]
                r = subprocess.run(cmd, capture_output=True, text=True)
                if r.returncode != 0:
                    return None
                return r.stdout.strip()
            for key in folder:
                driver_path = get_prop(key, "OpenGLDriverName")
                if driver_path and os.path.isabs(driver_path):
                    os.system(
                        'reg add "HKLM\\SYSTEM\\ControlSet001\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\'
                        + key +
                        '" /v "OpenGLDriverName" /t REG_SZ /d "' + driver_path + '" /f'
                    )
                    print(True)"""

        case '0':
                break